package com.example.android.quizapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class QuizApp extends AppCompatActivity {

    /**
     * Defined Variables for Lincoln CheckBox
     */

    CheckBox lincolnCheckBox;
    boolean pickedLincoln;

    /**
     * Defined Variables for Washington CheckBox
     */

    CheckBox washingtonCheckBox;
    boolean pickedWashington;

    /**
     * Defined Variables for Franklin CheckBox
     */

    CheckBox franklinCheckBox;
    boolean pickedFranklin;

    /**
     * Defined Variables for Hamilton CheckBox
     */

    CheckBox hamiltonCheckBox;
    boolean pickedHamilton;

    /**
     * Defined Variables for FiftySix CheckBox
     */

    CheckBox fiftySixCheckBox;
    boolean pickedFiftySix;

    /**
     * Defined Variables for EightyFive CheckBox
     */

    CheckBox eightyFiveCheckBox;
    boolean pickedEightyFive;

    /**
     * Defined Variables for SeventyTwo CheckBox
     */

    CheckBox seventyTwoCheckBox;
    boolean pickedSeventyTwo;

    /**
     * Defined Variables for Sixty-Five CheckBox
     */

    CheckBox sixtyFiveCheckBox;
    boolean pickedSixtyFive;

    /**
     * Defined Variables for February CheckBox
     */

    CheckBox februaryCheckBox;
    boolean pickedFebruary;

    /**
     * Defined Variables for December CheckBox
     */

    CheckBox decemberCheckBox;
    boolean pickedDecember;

    /**
     * Defined Variables for January CheckBox
     */

    CheckBox januaryCheckBox;
    boolean pickedJanuary;

    /**
     * Defined Variables for November CheckBox
     */

    CheckBox novemberCheckBox;
    boolean pickedNovember;

    /**
     * Defined Variables for Fifty-Seven CheckBox
     */

    CheckBox fiftySevenCheckBox;
    boolean pickedFiftySevenCheckBox;

    /**
     * Defined Variables for Forty-Four CheckBox
     */

    CheckBox fortyFourCheckBox;
    boolean pickedFortyFour;

    /**
     * Defined Variables for Seventy-Seven CheckBox
     */

    CheckBox seventySevenCheckBox;
    boolean pickedSeventySeven;

    /**
     * Defined Variables for Seventy-Six CheckBox
     */

    CheckBox seventySixCheckBox;
    boolean pickedSeventySix;

    /**
     * Defined Variables for Martin Luther King jr. CheckBox
     */

    CheckBox martinCheckBox;
    boolean pickedMlk;

    /**
     * Defined Variables for Barack Obama CheckBox
     */

    CheckBox obamaCheckBox;
    boolean pickedObama;

    /**
     * Defined Variables for Collin Powell CheckBox
     */

    CheckBox powellCheckBox;
    boolean pickedPowell;

    CheckBox malcomCheckBox;
    boolean pickedMalcom;

    CheckBox hundredCheckBox;
    boolean pickedHundred;

    CheckBox fiftyCheckBox;
    boolean pickedFifty;

    CheckBox sixtyCheckBox;
    boolean pickedSixty;

    CheckBox seventyCheckBox;
    boolean pickedSeventy;

    CheckBox nineCheckBox;
    boolean pickedNine;

    CheckBox sevenCheckBox;
    boolean pickedSeven;

    CheckBox elevenCheckBox;
    boolean pickedEleven;

    CheckBox thirteenCheckBox;
    boolean pickedThirteen;

    /**
     * Public Wrong Text Views
     */

    TextView wrongOne;
    TextView wrongTwo;
    TextView wrongThree;
    TextView wrongFour;
    TextView wrongFive;
    TextView wrongSix;
    TextView wrongSeven;
    TextView wrongEight;
    TextView wrongNine;
    TextView wrongTen;
    TextView wrongEleven;
    TextView wrongTwelve;
    TextView wrongThirteen;
    TextView wrongFourteen;
    TextView wrongFifteen;
    TextView wrongSixteen;
    TextView wrongSeventeen;
    TextView wrongEighteen;
    TextView wrongNineteen;
    TextView wrongTwenty;
    TextView wrongTwentyOne;

    /**
     * Public Correct Text Views
     */

    TextView correctOne;
    TextView correctTwo;
    TextView correctThree;
    TextView correctFour;
    TextView correctFive;
    TextView correctSix;
    TextView correctSeven;



    /**
     * This app displays a total history knowledge for the user
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_app);

/**
 * Wrong - Lincoln Checkbox variable link
 */
        lincolnCheckBox = (CheckBox) findViewById(R.id.lincoln_checkbox);
        pickedLincoln = lincolnCheckBox.isChecked();
        wrongOne = (TextView) findViewById(R.id.wrongone_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        franklinCheckBox = (CheckBox) findViewById(R.id.franklin_checkbox);
        pickedFranklin = franklinCheckBox.isChecked();
        wrongTwo = (TextView) findViewById(R.id.wrongtwo_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        hamiltonCheckBox = (CheckBox) findViewById(R.id.hamilton_checkbox);
        pickedHamilton = hamiltonCheckBox.isChecked();
        wrongThree = (TextView) findViewById(R.id.wrongthree_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        fiftySixCheckBox = (CheckBox) findViewById(R.id.fiftySix_checkbox);
        pickedFiftySix = fiftySixCheckBox.isChecked();
        wrongFour = (TextView) findViewById(R.id.wrongfour_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        eightyFiveCheckBox = (CheckBox) findViewById(R.id.eightyfive_checkbox);
        pickedEightyFive = eightyFiveCheckBox.isChecked();
        wrongFive = (TextView) findViewById(R.id.wrongfive_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        seventyTwoCheckBox = (CheckBox) findViewById(R.id.seventytwo_checkbox);
        pickedSeventyTwo = seventyTwoCheckBox.isChecked();
        wrongSix = (TextView) findViewById(R.id.wrongsix_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        februaryCheckBox = (CheckBox) findViewById(R.id.february_checkbox);
        pickedFebruary = februaryCheckBox.isChecked();
        wrongSeven = (TextView) findViewById(R.id.wrongseven_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        decemberCheckBox = (CheckBox) findViewById(R.id.december_checkbox);
        pickedDecember = decemberCheckBox.isChecked();
        wrongEight = (TextView) findViewById(R.id.wrongeight_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        novemberCheckBox = (CheckBox) findViewById(R.id.november_checkbox);
        pickedNovember = novemberCheckBox.isChecked();
        wrongNine = (TextView) findViewById(R.id.wrongnine_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        fiftySevenCheckBox = (CheckBox) findViewById(R.id.fiftySeven_checkbox);
        pickedFiftySevenCheckBox = fiftySevenCheckBox.isChecked();
        wrongTen = (TextView) findViewById(R.id.wrongten_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        fortyFourCheckBox = (CheckBox) findViewById(R.id.fortyFour_checkbox);
        pickedFortyFour = fortyFourCheckBox.isChecked();
        wrongEleven = (TextView) findViewById(R.id.wrongeleven_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        seventySevenCheckBox = (CheckBox) findViewById(R.id.seventySeven_checkbox);
        pickedSeventySeven = seventySevenCheckBox.isChecked();
        wrongTwelve = (TextView) findViewById(R.id.wrongtwelve_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        martinCheckBox = (CheckBox) findViewById(R.id.mlk_checkbox);
        pickedMlk = martinCheckBox.isChecked();
        wrongThirteen = (TextView) findViewById(R.id.wrongthirteen_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        powellCheckBox = (CheckBox) findViewById(R.id.powell_checkbox);
        pickedPowell = powellCheckBox.isChecked();
        wrongFourteen = (TextView) findViewById(R.id.wrongfourteen_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        malcomCheckBox = (CheckBox) findViewById(R.id.malcom_checkbox);
        pickedMalcom = malcomCheckBox.isChecked();
        wrongFifteen = (TextView) findViewById(R.id.wrongfifteen_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        hundredCheckBox = (CheckBox) findViewById(R.id.hundred_checkbox);
        pickedHundred = hundredCheckBox.isChecked();
        wrongSixteen = (TextView) findViewById(R.id.wrongsixteen_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        sixtyCheckBox = (CheckBox) findViewById(R.id.sixty_checkbox);
        pickedSixty = sixtyCheckBox.isChecked();
        wrongSeventeen = (TextView) findViewById(R.id.wrongseventeen_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        seventyCheckBox = (CheckBox) findViewById(R.id.seventy_checkbox);
        pickedSeventy = seventyCheckBox.isChecked();
        wrongEighteen = (TextView) findViewById(R.id.wrongeighteen_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        nineCheckBox = (CheckBox) findViewById(R.id.nine_checkbox);
        pickedNine = nineCheckBox.isChecked();
        wrongNineteen = (TextView) findViewById(R.id.wrongnineteen_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        sevenCheckBox = (CheckBox) findViewById(R.id.seven_checkbox);
        pickedSeven = sevenCheckBox.isChecked();
        wrongTwenty = (TextView) findViewById(R.id.wrongtwenty_text_view);
/**
 * Wrong - Lincoln Checkbox variable link
 */
        elevenCheckBox = (CheckBox) findViewById(R.id.eleven_checkbox);
        pickedEleven = elevenCheckBox.isChecked();
        wrongTwentyOne = (TextView) findViewById(R.id.wrongtwentyone_text_view);

/**
 * Correct - Washington Checkbox variable Link
 */
        washingtonCheckBox = (CheckBox) findViewById(R.id.washington_checkbox);
        pickedWashington = washingtonCheckBox.isChecked();
        correctOne = (TextView) findViewById(R.id.correctone_text_view);
/**
 * Correct - 1865 Checkbox variable Link
 */
        sixtyFiveCheckBox = (CheckBox) findViewById(R.id.sixtyFive_checkbox);
        pickedSixtyFive = sixtyFiveCheckBox.isChecked();
        correctTwo = (TextView) findViewById(R.id.correcttwo_text_view);
/**
 * Correct - January 1920 Checkbox variable Link
 */
        januaryCheckBox = (CheckBox) findViewById(R.id.january_checkbox);
        pickedJanuary = januaryCheckBox.isChecked();
        correctThree = (TextView) findViewById(R.id.correctthree_text_view);
/**
 * Correct - 1776 Checkbox variable Link
 */
        seventySixCheckBox = (CheckBox) findViewById(R.id.seventySix_checkbox);
        pickedSeventySix = seventySixCheckBox.isChecked();
        correctFour = (TextView) findViewById(R.id.correctfour_text_view);
/**
 * Correct - Barrak Obama Checkbox variable Link
 */
        obamaCheckBox = (CheckBox) findViewById(R.id.obama_checkbox);
        pickedObama = obamaCheckBox.isChecked();
        correctFive = (TextView) findViewById(R.id.correctfive_text_view);
/**
 *Correct - 50 Checkbox variable Link
 */
        fiftyCheckBox = (CheckBox) findViewById(R.id.fifty_checkbox);
        pickedFifty = fiftyCheckBox.isChecked();
        correctSix = (TextView) findViewById(R.id.correctsix_text_view);
/**
 * Correct - 13 Checkbox variable Link
 */
        thirteenCheckBox = (CheckBox) findViewById(R.id.thirteen_checkbox);
        pickedThirteen = thirteenCheckBox.isChecked();
        correctSeven = (TextView) findViewById(R.id.correctseven_text_view);

    }

    /**
     * This method is called when the Reset button is clicked
     */
    public void resetAnswer(View view) {
        /**
         * Display that Resets all of the Checkboxes and Answer column back to original
          */
        displayResetAnswer();
        /**
         * Displays Try Again in the Total Score Summary
         */
        String retryMessage = "Try Again";
        displayMessage(retryMessage);


    }
    /**
     * Sets Wrong Statement to Starting Display when the reset button is clicked.
     */
    private void displayResetAnswer() {

        wrongOne.setText("Answer");
        getString(R.string.Lincoln);
        if (lincolnCheckBox.isChecked()) {
            lincolnCheckBox.setChecked(false);
        }

        wrongTwo.setText("Answer");
        getString(R.string.Franklin);
        if (franklinCheckBox.isChecked()) {
            franklinCheckBox.setChecked(false);
        }

        wrongThree.setText("Answer");
        getString(R.string.Hamilton);
        if (hamiltonCheckBox.isChecked()) {
            hamiltonCheckBox.setChecked(false);
        }


        wrongFour.setText("Answer");
        getString(R.string.FiftySix);
        if (fiftySixCheckBox.isChecked()) {
            fiftySixCheckBox.setChecked(false);
        }


        wrongFive.setText("Answer");
        getString(R.string.EightyFive);
        if (eightyFiveCheckBox.isChecked()) {
            eightyFiveCheckBox.setChecked(false);
        }


        wrongSix.setText("Answer");
        getString(R.string.SeventyTwo);
        if (seventyTwoCheckBox.isChecked()) {
            seventyTwoCheckBox.setChecked(false);
        }

        wrongSeven.setText("Answer");
        getString(R.string.February);
        if (februaryCheckBox.isChecked()) {
            februaryCheckBox.setChecked(false);
        }

        wrongEight.setText("Answer");
        getString(R.string.December);
        if (decemberCheckBox.isChecked()) {
            decemberCheckBox.setChecked(false);
        }

        wrongNine.setText("Answer");
        getString(R.string.November);
        if (novemberCheckBox.isChecked()) {
            novemberCheckBox.setChecked(false);
        }

        wrongTen.setText("Answer");
        getString(R.string.SeventySeven);
        if (seventySevenCheckBox.isChecked()) {
            seventySevenCheckBox.setChecked(false);
        }

        wrongEleven.setText("Answer");
        getString(R.string.FiftySeven);
        if (fiftySevenCheckBox.isChecked()) {
            fiftySevenCheckBox.setChecked(false);
        }

        wrongTwelve.setText("Answer");
        getString(R.string.FortyFour);
        if (fortyFourCheckBox.isChecked()) {
            fortyFourCheckBox.setChecked(false);
        }

        wrongThirteen.setText("Answer");
        getString(R.string.Martin);
        if (martinCheckBox.isChecked()) {
            martinCheckBox.setChecked(false);
        }

        wrongFourteen.setText("Answer");
        getString(R.string.Powell);
        if (powellCheckBox.isChecked()) {
            powellCheckBox.setChecked(false);
        }

        wrongFifteen.setText("Answer");
        getString(R.string.Malcom);
        if (malcomCheckBox.isChecked()) {
            malcomCheckBox.setChecked(false);
        }

        wrongSixteen.setText("Answer");
        getString(R.string.Hundred);
        if (hundredCheckBox.isChecked()) {
            hundredCheckBox.setChecked(false);
        }

        wrongSeventeen.setText("Answer");
        getString(R.string.Sixty);
        if (sixtyCheckBox.isChecked()) {
            sixtyCheckBox.setChecked(false);
        }


        wrongEighteen.setText("Answer");
        getString(R.string.Seventy);
        if (seventyCheckBox.isChecked()) {
            seventyCheckBox.setChecked(false);
        }


        wrongNineteen.setText("Answer");
        getString(R.string.Nine);
        if (nineCheckBox.isChecked()) {
            nineCheckBox.setChecked(false);
        }


        wrongTwenty.setText("Answer");
        getString(R.string.Seven);
        if (sevenCheckBox.isChecked()) {
            sevenCheckBox.setChecked(false);
        }

        wrongTwentyOne.setText("Answer");
        getString(R.string.Eleven);
        if (elevenCheckBox.isChecked()) {
            elevenCheckBox.setChecked(false);
        }

        /**
         * Sets Correct Statement to Starting Display when the reset button is clicked.
         */

        correctOne.setText("Answer");
        if (washingtonCheckBox.isChecked()) {
            washingtonCheckBox.setChecked(false);
        }


        correctTwo.setText("Answer");
        if (sixtyFiveCheckBox.isChecked()) {
            sixtyFiveCheckBox.setChecked(false);
        }


        correctThree.setText("Answer");
        if (januaryCheckBox.isChecked()) {
            januaryCheckBox.setChecked(false);
        }


        correctFour.setText("Answer");
        if (seventySixCheckBox.isChecked()) {
            seventySixCheckBox.setChecked(false);
        }


        correctFive.setText("Answer");
        if (obamaCheckBox.isChecked()) {
            obamaCheckBox.setChecked(false);
        }



        correctSix.setText("Answer");
        if (fiftyCheckBox.isChecked()) {
            fiftyCheckBox.setChecked(false);
        }

        correctSeven.setText("Answer");
        if (thirteenCheckBox.isChecked()) {
            thirteenCheckBox.setChecked(false);
        }
    }


    /**
     * This method is called when the Submit button is clicked.
     */
    public void submitAnswer(View view) {
        boolean pickedWashington = washingtonCheckBox.isChecked();
        boolean pickedSixtyFive = sixtyFiveCheckBox.isChecked();
        boolean pickedJanuary = januaryCheckBox.isChecked();
        boolean pickedSeventySeven = seventySevenCheckBox.isChecked();
        boolean pickedObama = obamaCheckBox.isChecked();
        boolean pickedFifty = fiftyCheckBox.isChecked();
        boolean pickedThirteen = thirteenCheckBox.isChecked();

        // Calculate the total
        int baseScore = calculateTotal(pickedWashington,pickedSixtyFive,pickedJanuary,pickedSeventySeven,pickedObama,pickedFifty,pickedThirteen);
        /**
         * Sets the max amount of possible total to 7
         */
        int total = 7;

        /**
         * Displays the total percentage on the quiz
         */
        float totalPercentage = (baseScore * 100f)/ total;

        // Display the total summary on the screen
        String resultsMessage = "Total Score: \n";
        baseScore = calculateTotal(pickedWashington, pickedSixtyFive, pickedJanuary, pickedSeventySeven, pickedObama, pickedFifty, pickedThirteen);
        resultsMessage += + baseScore;
        resultsMessage += "/" + total + "\n";
        resultsMessage += totalPercentage + "%";
        displayMessage(resultsMessage);

        /**
         *  Displays Right or Wrong Answers in the answer column
         */

        displaySubmit();
    }

    /**
     * Calculates total correct in quiz
     /**
     * @param pickedWashington is whether or not the user picked washington as an answer
     * @param pickedSixtyFive is whether or not the user picked washington as an answer
     * @param pickedJanuary is whether or not the user picked washington as an answer
     * @param pickedSeventySeven is whether or not the user picked washington as an answer
     * @param pickedObama is whether or not the user picked washington as an answer
     * @param pickedFifty is whether or not the user picked washington as an answer
     * @param pickedThirteen is whether or not the user picked washington as an answer
     * @return baseScore;
     */
    private int calculateTotal(boolean pickedWashington, boolean pickedSixtyFive, boolean pickedJanuary, boolean pickedSeventySeven, boolean pickedObama, boolean pickedFifty, boolean pickedThirteen) {

        /**
         *  Displays the initial number of 0 correct when user starts quiz
         */

        int baseScore = 0;

        /**
         *  Adds total correct to baseScore to calculate the total the user got on the quiz
         */


        if (pickedWashington) {
            baseScore = baseScore + 1;
        }
        if (pickedSixtyFive) {
            baseScore = baseScore + 1;
        }
        if (pickedJanuary) {
            baseScore = baseScore + 1;
        }
        if (pickedSeventySeven) {
            baseScore = baseScore + 1;
        }
        if (pickedObama) {
            baseScore = baseScore + 1;
        }
        if (pickedFifty) {
            baseScore = baseScore + 1;
        }
        if (pickedThirteen) {
            baseScore = baseScore + 1;
        }


        return baseScore;



    }

    /**
     * This method displays the given price on the screen.
     */
    private void displayMessage(String message) {
        TextView resultsTextView = (TextView) findViewById(R.id.results_text_view);
        resultsTextView.setText(message);

    }

    /**
     * This method displays Wrong answers
     */
    private void displaySubmit() {

        wrongOne.setText("Wrong");

        wrongTwo.setText("Wrong");

        wrongThree.setText("Wrong");

        wrongFour.setText("Wrong");

        wrongFive.setText("Wrong");

        wrongSix.setText("Wrong");

        wrongSeven.setText("Wrong");

        wrongEight.setText("Wrong");

        wrongNine.setText("Wrong");

        wrongTen.setText("Wrong");

        wrongEleven.setText("Wrong");

        wrongTwelve.setText("Wrong");

        wrongThirteen.setText("Wrong");

        wrongFourteen.setText("Wrong");

        wrongFifteen.setText("Wrong");

        wrongSixteen.setText("Wrong");

        wrongSeventeen.setText("Wrong");

        wrongEighteen.setText("Wrong");

        wrongNineteen.setText("Wrong");

        wrongTwenty.setText("Wrong");

        wrongTwentyOne.setText("Wrong");

        /**
         * This method displays Correct answers
         */

        correctOne.setText("Correct");

        correctTwo.setText("Correct");

        correctThree.setText("Correct");

        correctFour.setText("Correct");

        correctFive.setText("Correct");

        correctSix.setText("Correct");

        correctSeven.setText("Correct");
    }

}

